/* #undef __USE_COMPLEX__ */
#define __USE_DOUBLE__
/* #undef __USE_64BIT__ */
